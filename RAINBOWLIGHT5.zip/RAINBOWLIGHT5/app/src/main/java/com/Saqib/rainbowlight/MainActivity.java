package com.Saqib.rainbowlight;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;



public class MainActivity extends AppCompatActivity {
    // Declaring variables
    private EditText rgbValues;
    private boolean motion = true;
    private boolean led = false;
    private boolean sendColor = false;
    private Button buttonSend;
    private Button onOffButton;
    private Button motionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Attaching string id with button
        buttonSend = findViewById(R.id.sendButton);
        onOffButton = findViewById(R.id.onOffButton);
        motionButton = findViewById(R.id.motionsensor);
        motionButton.setBackgroundColor(Color.GREEN);

        // Attaching String id to text field
        rgbValues = findViewById(R.id.rgbEditText);

        // Adding button click registration
      /*  onOffButton.setOnClickListener(this);
        motionButton.setOnClickListener(this);
        buttonSend.setOnClickListener(this);*/

        // If on/off button is clicked it sends a message depending on the boolean led
        onOffButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg;
                if (led) {
                    msg = "L0";
                    onOffButton.setBackgroundColor(Color.GRAY);
                } else {
                    msg = "L1";
                    onOffButton.setBackgroundColor(Color.GREEN);
                }
                try {
                    sendMessage(msg);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        // If motion button is clicked it sends a message depending on the boolean motionOn
        motionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg2;
                if (motion) {
                    msg2 = "M0";
                    motionButton.setBackgroundColor(Color.GRAY);
                } else {
                    msg2 = "M1";
                    motionButton.setBackgroundColor(Color.GREEN);
                }
                try {
                    sendMessage(msg2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = rgbValues.getText().toString();
                if (text.equals("0,0,0") || text.equals("")) {
                    sendMessage(rgbValues.getText().toString());
                    onOffButton.setBackgroundColor(Color.GRAY);
                    led = false;
                    rgbValues.getText().clear();
                } else {
                    try {
                        sendMessage(rgbValues.getText().toString());
                        onOffButton.setBackgroundColor(Color.GREEN);
                        led = true;
                        rgbValues.getText().clear();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });


    }


    // If clicked on the send button it takes the input from the text field and sends it to arduino
  /*  @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.sendButton:
                sendMessage(rgbValues.getText().toString());
                rgbValues.getText().clear();
                break;
        }
    }*/

    // Sending function which takes a string as input parameter
    private void sendMessage(final String message) {
        Thread thread = new Thread(new Runnable() {

            String stringData;

            @Override
            public void run() {

                // Opening UDP socket
                DatagramSocket socket = null;
                try {

                    socket = new DatagramSocket();
                    // IP Address of arduino.
                    InetAddress arduinoAddr = InetAddress.getByName("192.168.1.107"); //192.168.1.102
                    // Creating UDP packet and sending to arduinos IP and on port 8888
                    DatagramPacket data;
                    data = new DatagramPacket(message.getBytes(), message.length(), arduinoAddr, 8888);
                    socket.send(data);

                    // Receiving data packets from arduino
                    byte[] msgSize = new byte[1000];
                    data = new DatagramPacket(msgSize, msgSize.length);
                    socket.receive(data);
                    // Making the received data to a string and depending on what the string contains,
                    // the booleans for the motionsensor and LED power changes.
                    stringData = new String(msgSize, 0, data.getLength());
                    if (stringData.equals("L1")) {
                            led = true;
                        }
                    if (stringData.equals("L0")){
                        led = false;
                    }

                    if (stringData.equals("M1")) {
                            motion = true;
                        }
                    if (stringData.equals("M0")){
                        motion = false;
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (socket != null) {
                        socket.close();
                    }
                }
            }
        });

        thread.start();
    }
}